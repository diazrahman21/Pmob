package com.example.pertemuanterakhirnihh

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.example.pertemuanterakhirnihh.databinding.ItemBioskopBinding

class AdapterBioskop(private val data: List<ModelBioskop>) :
    RecyclerView.Adapter<AdapterBioskop.PekerjaanViewHolder>() {
    class PekerjaanViewHolder(private val binding: ItemBioskopBinding) :
        RecyclerView.ViewHolder(binding.root) {
        fun bind(employee: ModelBioskop) {
            binding.tvNama.text = employee.nama
            binding.tvLokasi.text = employee.lokasi
            Glide.with(binding.root.context)
                .load(employee.photoUrl)
                .centerCrop()
                .into(binding.ivPhotos)
        }
    }
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): PekerjaanViewHolder {
        val binding = ItemBioskopBinding.inflate(
            LayoutInflater.from(parent.context),
            parent,
            false
        )
        return PekerjaanViewHolder(binding)
    }
    override fun onBindViewHolder(holder: PekerjaanViewHolder, position: Int) {
        val data = data[position]
        holder.bind(data)
    }
    override fun getItemCount(): Int = data.size
}