package com.example.pertemuanterakhirnihh

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.example.pertemuanterakhirnihh.databinding.ActivityMapsBinding
import com.google.android.gms.maps.CameraUpdateFactory
import com.google.android.gms.maps.GoogleMap
import com.google.android.gms.maps.OnMapReadyCallback
import com.google.android.gms.maps.SupportMapFragment
import com.google.android.gms.maps.model.LatLng
import com.google.android.gms.maps.model.MarkerOptions

class MapsActivity : AppCompatActivity(), OnMapReadyCallback {
    private lateinit var binding: ActivityMapsBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMapsBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val mapFragment = supportFragmentManager
            .findFragmentById(R.id.maps) as SupportMapFragment
        mapFragment.getMapAsync(this)
    }

    override fun onMapReady(googleMap: GoogleMap) {
        // Tambahkan marker di empire_xxi, Indonesia,
        // dan pindahkan kamera peta ke lokasi yang sama.
        val empire_xxi = LatLng(-7.783193492338215, 110.38689401071265)
        
        googleMap.addMarker(MarkerOptions().position(empire_xxi).title("Lokasi EMPIRE XXI 4 YOGYAKARTA"))
        googleMap.moveCamera(CameraUpdateFactory.newLatLng(empire_xxi))
    }
}