package com.example.pertemuanterakhirnihh

data class ModelBioskop(
    val nama: String? = null,
    val lokasi: String? =null,
    val photoUrl: String? =null,
)
