package com.example.pertemuan8_ajah

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.widget.EditText
import android.widget.Toast
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.pertemuan8_ajah.databinding.ActivityBioskopBinding
import com.example.pertemuan8_ajah.databinding.ActivityPekerjaanBinding
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener

class BioskopActivity : AppCompatActivity() {
    private lateinit var binding: ActivityBioskopBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityBioskopBinding.inflate(layoutInflater)
        setContentView(binding.root)
        binding.rvPekerjaan.layoutManager = LinearLayoutManager(this)
        binding.rvPekerjaan.setHasFixedSize(true)
        showData()
        tambahData()
    }
    private fun showData() {
        val dataRef = FirebaseDatabase.getInstance().getReference("Restoran")
        dataRef.addValueEventListener(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                val pekerjaanList = mutableListOf<ModelBioskop>()
                val adapter = AdapterBioskop(pekerjaanList)
                for (dataSnapshot in snapshot.children) {
                    val pekerjaanKey = dataSnapshot.getValue(ModelBioskop::class.java)
                    pekerjaanKey?.let {
                        pekerjaanList.add(it)
                        Log.d("cek data firebase", it.toString())
                    }
                }
                if (pekerjaanList.isNotEmpty()) {
                    binding.rvPekerjaan.adapter = adapter
                } else {
                    Toast.makeText(this@BioskopActivity, "Data not found",
                        Toast.LENGTH_LONG).show()
                }
            }
            override fun onCancelled(snapshot: DatabaseError) {
// Handle onCancelled
            }
        })
    }
    private fun tambahData(){
        val database: FirebaseDatabase = FirebaseDatabase.getInstance()
        val pekerjaanRef: DatabaseReference = database.getReference("Restoran")
        binding.fabAddPekerjaan.setOnClickListener {
            val dialogView = LayoutInflater.from(this).inflate(R.layout.upload_bioskop, null)
            MaterialAlertDialogBuilder(this)
                .setTitle("Tambah Restoran")
                .setView(dialogView)
                .setPositiveButton("Tambah") { dialog, _ ->
                    val jobName =
                        dialogView.findViewById<EditText>(R.id.editTextJobName).text.toString()
                    val shift = dialogView.findViewById<EditText>(R.id.editTextShift).text.toString()
                    val pekerjaanData = HashMap<String, Any>()
                    pekerjaanData["nama"] = jobName
                    pekerjaanData["lokasi"] = shift
                    Log.d("aku", jobName)
                    val newPekerjaanRef = pekerjaanRef.push()
                    newPekerjaanRef.setValue(pekerjaanData)
                    dialog.dismiss()
                }
                .setNegativeButton("Batal") { dialog, _ ->
                    dialog.dismiss()
                }
                .show()
        }
    }
}