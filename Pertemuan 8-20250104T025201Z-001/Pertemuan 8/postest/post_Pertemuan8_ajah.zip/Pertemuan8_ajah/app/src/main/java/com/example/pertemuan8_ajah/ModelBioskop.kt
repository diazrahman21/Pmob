package com.example.pertemuan8_ajah

data class ModelBioskop (
    val nama: String? = null,
    val lokasi: String? =null,
)