package com.example.pertemuan8_ajah

data class ModelPekerjaan(
    val nama: String? = null,
    val shift: String? =null,
)